package com.exampleRedis.Redis.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exampleRedis.Redis.DTO.UserDTO;
import com.exampleRedis.Redis.Service.UserService;

@RestController("/user")
public class UserController {

	@Autowired
	UserService userService;
	
	@PostMapping("/save")
	public void saveUsers(@RequestBody UserDTO userDTO) {
		try {
			userService.saveUsers(userDTO);
		}
		catch(Exception e) {
			System.err.println(e);
		}
	}
}
