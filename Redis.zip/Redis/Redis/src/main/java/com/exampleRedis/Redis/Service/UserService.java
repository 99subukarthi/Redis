package com.exampleRedis.Redis.Service;

import com.exampleRedis.Redis.DTO.UserDTO;

public interface UserService {

	public void saveUsers(UserDTO dto) throws Exception;
	
}
