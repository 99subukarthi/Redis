package com.exampleRedis.Redis.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exampleRedis.Redis.DTO.UserDTO;
import com.exampleRedis.Redis.repository.RedisRepository;

@Service
public class UserServiceImpl implements UserService{

	
	@Autowired
	RedisRepository redisRepository;
	
	@Override
	public void saveUsers(UserDTO dto) throws Exception {
		redisRepository.saveUser(dto);
	}

	
	
}
