package com.exampleRedis.Redis.repository;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.exampleRedis.Redis.DTO.UserDTO;

@Repository
public class RedisRepository{

	private String USER_KEY="USER";
	
	
	@Autowired
	private RedisTemplate<Object, Object> redisTemplate;
	
	public void saveUser(UserDTO userDTO) {
		try {
			redisTemplate.opsForHash().put(USER_KEY, userDTO.getUserId(), userDTO);
		}
		catch(Exception e) {
			System.err.println(e);
		}
		
	}
}
