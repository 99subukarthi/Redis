package com.exampleRedis.Redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
